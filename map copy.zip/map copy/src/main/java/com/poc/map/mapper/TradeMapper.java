package com.poc.map.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.poc.map.dto.StageDto;
import com.poc.map.dto.TradeDto;

@Mapper
public interface TradeMapper {

    TradeMapper MAPPER = Mappers.getMapper( TradeMapper.class );

    @Mapping(target = "tradeId", expression = "java(parseTradeId(s.getRecord()))")
    @Mapping(target = "tradeCategory", expression = "java(parseTradeCategory(s.getRecord()))")
    @Mapping(target = "tradeType", expression = "java(parseTradeType(s.getRecord()))")
    TradeDto toTarget(StageDto s);

    default String parseTradeId(String record) {
        // Logic to parse and extract tradeId from record
        // Example logic:
        return record.split(",")[0];
    }

    default String parseTradeCategory(String record) {
        // Logic to parse and extract tradeCategory from record
        // Example logic:
        return record.split(",")[1];
    }

    default String parseTradeType(String record) {
        // Logic to parse and extract tradeType from record
        // Example logic:
        return record.split(",")[2];
    }
}
