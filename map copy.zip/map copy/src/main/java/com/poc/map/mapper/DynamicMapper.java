package com.poc.map.mapper;

import com.poc.map.dto.ProductDto;
import com.poc.map.dto.RiskDto;
import com.poc.map.dto.StageDto;
import com.poc.map.dto.TradeDto;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface DynamicMapper {

    DynamicMapper INSTANCE = Mappers.getMapper(DynamicMapper.class);

    @Mapping(target = "name", source = "record", qualifiedByName = "parseName")
    @Mapping(target = "description", source = "record", qualifiedByName = "parseDescription")
    ProductDto toProductDto(StageDto stageDto);

    @Mapping(target = "riskId", source = "record", qualifiedByName = "parseRiskId")
    @Mapping(target = "riskDescription", source = "record", qualifiedByName = "parseRiskDescription")
    RiskDto toRiskDto(StageDto stageDto);

    @Mapping(target = "tradeId", source = "record", qualifiedByName = "parseTradeId")
    @Mapping(target = "tradeCategory", source = "record", qualifiedByName = "parseTradeCategory")
    @Mapping(target = "tradeType", source = "record", qualifiedByName = "parseTradeType")
    TradeDto toTradeDto(StageDto stageDto);

    @Named("parseName")
    default String parseName(String record) {
        return parseField(record, 0);
    }

    @Named("parseDescription")
    default String parseDescription(String record) {
        return parseField(record, 1);
    }

    @Named("parseRiskId")
    default String parseRiskId(String record) {
        return parseField(record, 0);
    }

    @Named("parseRiskDescription")
    default String parseRiskDescription(String record) {
        return parseField(record, 1);
    }

    @Named("parseTradeId")
    default String parseTradeId(String record) {
        return parseField(record, 0);
    }

    @Named("parseTradeCategory")
    default String parseTradeCategory(String record) {
        return parseField(record, 1);
    }

    @Named("parseTradeType")
    default String parseTradeType(String record) {
        return parseField(record, 2);
    }

    default String parseField(String record, int index) {
        String[] fields = record.split(",");
        return fields.length > index ? fields[index] : null;
    }
}
