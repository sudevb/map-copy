package com.poc.map.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.poc.map.dto.StageDto;
import com.poc.map.dto.RiskDto;

@Mapper
public interface RiskMapper {

    RiskMapper MAPPER = Mappers.getMapper( RiskMapper.class );

    @Mapping(target = "riskId", expression = "java(parseRiskId(s.getRecord()))")
    @Mapping(target = "riskDescription", expression = "java(parseRiskDescription(s.getRecord()))")
    RiskDto toTarget(StageDto s);

    default String parseRiskId(String record) {
        // Logic to parse and extract riskId from record
        // Example logic:
        return record.split(",")[0];
    }

    default String parseRiskDescription(String record) {
        // Logic to parse and extract riskDescription from record
        // Example logic:
        return record.split(",")[1];
    }
}
