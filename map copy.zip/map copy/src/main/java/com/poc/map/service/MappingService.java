package com.poc.map.service;

import com.poc.map.dto.ProductDto;
import com.poc.map.dto.RiskDto;
import com.poc.map.dto.StageDto;
import com.poc.map.dto.TradeDto;
import com.poc.map.mapper.DynamicMapper;
import org.springframework.stereotype.Service;

@Service
public class MappingService {

    private final DynamicMapper dynamicMapper;

    public MappingService(DynamicMapper dynamicMapper) {
        this.dynamicMapper = dynamicMapper;
    }

    public Object mapToTarget(StageDto stageDto) {
        switch (stageDto.getType()) {
            case "ProductType":
                return dynamicMapper.toProductDto(stageDto);
            case "RiskType":
                return dynamicMapper.toRiskDto(stageDto);
            case "TradeType":
                return dynamicMapper.toTradeDto(stageDto);
            default:
                throw new IllegalArgumentException("Unknown type: " + stageDto.getType());
        }
    }
}
